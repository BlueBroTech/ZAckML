# ZAckML — Zack's Actionable "compression key-like" Markup Language

**Specification v1.0**

*Created by [Zack VonBluebaugh](https://github.com/VonBluebaugh) (BlueBroTech, LLC).*

ZAckML is a generic, extensible markup language in the XML family, designed for transmitting document content, metadata, and parameters as structured trees. The name is read as **Z-Ack-M-L**: the **Z** is possessive — *Zack's* (the author's initial) — **Ack** stands for *Actionable "compression key-like"* (a tag name is a short, actionable acknowledgement that stands in for a larger semantic definition), and **ML** stands for *Markup Language*.

Like XML, ZAckML has **no predefined tag names**. Unlike XML, ZAckML offers an optional in-band **pattern reference system**: a document may declare one or more pattern files that attach HTML-like semantics (rendering category, attribute schemas, defaults, child rules) to the tags it uses. Patterns are a layered semantic facility, not a grammatical requirement — a ZAckML parser consumes any valid document without resolving patterns.

This is a form of **semantic compression**: the practice of compacting a lexicon while retaining meaning, typically by replacing specific terms with more general counterparts (hypernyms) that can be expanded back when needed. A tag name in ZAckML is a compressed keyword — short to write, visually light in a document — and a referenced pattern is the decompressor, mapping each tag to its full semantic definition (rendering mode, attribute schema, defaults, child rules). A one-line pattern reference replaces what would otherwise be repeated boilerplate inside every document, and different patterns decompress the same keywords into different semantic spaces without touching the language grammar.

File extensions:

- `.zackml` — ZAckML documents
- `.pat` — ZAckML pattern files (themselves ZAckML documents)

---

## 1. Design principles

- **No reserved tag names.** Any name matching the `Name` grammar is valid.
- **Attribute values are always quoted.** Either `"..."` or `'...'`.
- **Whitespace in text content is significant by default.** Opt into collapsing per-element via `ws="collapse"`.
- **Patterns are optional and layered.** A document with no patterns is still valid ZAckML.
- **Silent fallback for undefined tags.** An unprefixed tag that no referenced pattern defines is a generic element with no semantic rules.
- **Errors are reserved for the uncomputable.** Pattern-aware processors error only when they genuinely cannot proceed (missing required values, failed validation with no default, unresolvable prefix, collision).

---

## 2. Conformance

A **ZAckML processor** MUST parse any syntactically valid document and produce a tree representation. A processor that encounters a syntactically invalid document MUST raise a parse error with line and column information.

A **pattern-aware processor** additionally resolves pattern references per Section 9. A processor that is not pattern-aware ignores pattern references entirely and sees only the generic element tree; this is a conforming behavior.

Keywords MUST, SHOULD, and MAY are used as in RFC 2119.

---

## 3. Lexical structure

### 3.1 Encoding

ZAckML documents are UTF-8. A leading BOM is permitted but not required. Line endings (`\r\n`, `\r`) MUST be normalized to `\n` at parse time. This normalization is separate from whitespace significance: the *kind* of newline is not significant, but the *presence* of one is.

### 3.2 Names

```
Name       ::= NameStart NameChar*
NameStart  ::= [A-Za-z_]
NameChar   ::= [A-Za-z0-9_-]
```

Names are case-sensitive. They are used for tag names, attribute names, prefix names, and processing-instruction targets.

### 3.3 Comments

```
<!-- anything except the sequence "-->" -->
```

Comments MAY appear anywhere an element may appear, plus in the prolog. They are not part of the element tree but MAY be preserved by processors.

### 3.4 Processing instructions

```
<?target?>
<?target attr="value" attr="value" ... ?>
```

Processing instructions appear in the document prolog (before the root element). Attribute values inside processing instructions follow the same quoting rules as element attributes.

Processing-instruction targets whose name begins with `zackml` (case-insensitive) are reserved for this specification.

---

## 4. Elements

### 4.1 Syntax

```
Element       ::= EmptyElement | PairedElement
EmptyElement  ::= '<' QName Attributes? S? '/>'
PairedElement ::= StartTag Content EndTag
StartTag      ::= '<' QName Attributes? S? '>'
EndTag        ::= '</' QName S? '>'
QName         ::= (Name ':')? Name
```

The `QName` of an `EndTag` MUST exactly match the `QName` of its corresponding `StartTag` (including any prefix).

### 4.2 Attributes

```
Attributes  ::= (S Attribute)+
Attribute   ::= Name S? '=' S? AttValue
AttValue    ::= '"' (Char - ('<' | '&' | '"') | EntityRef)* '"'
              | "'" (Char - ('<' | '&' | "'") | EntityRef)* "'"
```

Attribute values MUST be quoted. Both single and double quotes are permitted; the other style may appear unescaped inside. The `<` character MUST NOT appear inside an attribute value. Entities (see 6.2) are recognized inside attribute values.

Attribute names within a single element MUST be unique. Duplicate attribute names are a parse error.

**Bare boolean-style attributes** (`<tag flag>`) are NOT permitted in ZAckML. Use an explicit value: `<tag flag="true"/>`. A pattern may define the meaning of such values.

### 4.3 Root element

A document MUST contain exactly one root element, following any prolog content.

---

## 5. Content model

Element content MAY include, in any order and any quantity:

- Text
- Nested elements
- Comments
- CDATA sections
- Processing instructions (rare in element content; discouraged)

Mixed content — text interleaved with element children — is explicitly allowed.

---

## 6. Text and escaping

### 6.1 Whitespace

Whitespace in text content is **significant by default** and MUST be preserved verbatim by parsers (after line-ending normalization in 3.1).

An element MAY opt into whitespace collapsing by declaring a reserved attribute:

```
ws="preserve"   (default)
ws="collapse"
```

Under `ws="collapse"`, leading and trailing whitespace in each text node are trimmed, and internal runs of whitespace are collapsed to a single space. The setting is **inherited** by descendant elements unless a descendant declares its own `ws`. A pattern MAY declare a default `whitespace` mode per tag (see Section 10), which applies when the element does not carry an explicit `ws` attribute.

### 6.2 Entity references

The following entities are recognized in text content and in attribute values:

| Entity    | Expansion |
|-----------|-----------|
| `&amp;`   | `&`       |
| `&lt;`    | `<`       |
| `&gt;`    | `>`       |
| `&quot;`  | `"`       |
| `&apos;`  | `'`       |
| `&#D;`    | Unicode code point *D* (decimal) |
| `&#xH;`   | Unicode code point *H* (hexadecimal) |

Any other entity reference is a parse error. No DTD or custom entity mechanism is defined.

### 6.3 CDATA sections

```
<![CDATA[ ...literal... ]]>
```

Content inside a CDATA section is literal; `<`, `>`, and `&` need not be escaped. The sequence `]]>` MUST NOT appear literally inside a CDATA section.

---

## 7. Document structure

```
Document   ::= Prolog Element Trailing
Prolog     ::= XmlDecl? (Comment | ProcInst | S)*
XmlDecl    ::= '<?zackml' S Attribute (S Attribute)* S? '?>'
Trailing   ::= (Comment | S)*
```

The optional `<?zackml?>` declaration SHOULD appear as the first content of the document.

---

## 8. Standard processing instructions

### 8.1 `<?zackml?>`

```
<?zackml version="1.0" encoding="utf-8" ?>
```

| Attribute  | Required | Notes |
|------------|----------|-------|
| `version`  | yes      | Specification version.       |
| `encoding` | no       | Defaults to `"utf-8"`.       |

### 8.2 `<?pattern?>`

Declares a pattern reference. See Section 9 for semantics.

```
<?pattern src="html-basic.pat" as="h" strict="false" ?>
```

| Attribute | Required | Notes |
|-----------|----------|-------|
| `src`     | yes      | URI or relative path to a pattern file. |
| `as`      | no       | Binds the pattern to a prefix for explicit, reassuring attribution of elements to this pattern. |
| `strict`  | no       | `"true"` or `"false"` (default). When strict, an unprefixed tag undefined in any pattern is an error instead of a silent fallback. |

Multiple `<?pattern?>` instructions are allowed. Their **order is significant** — see 9.3.

---

## 9. Pattern system

### 9.1 Overview

A **pattern** is a mapping from tag names to semantic information: rendering category, attribute schemas with types and defaults, whitespace defaults, and a `maps-to` target used by renderers. Pattern files are themselves ZAckML documents (Section 10).

Resolving a pattern against a document attaches this information to each matching element and fills in attribute defaults. Non-matching elements remain generic.

### 9.2 Prefix binding

Each `<?pattern?>` instruction MAY declare a prefix via `as="..."`. Elements using that prefix — `<prefix:tag>` — resolve **exclusively** against that pattern.

Prefixes are the explicit, reassuring mechanism: when you write `<h:heading>`, it is unambiguous which pattern governs it.

**Binding the same prefix twice in a document is a collision error**, regardless of whether the patterns are identical.

### 9.3 Unprefixed resolution

An element without a prefix is resolved against the **most recently declared** pattern (last `<?pattern?>` in document order) that defines the tag *and does not carry an `as` prefix*. Prefix-bound patterns do not participate in unprefixed resolution; they only respond to their declared prefix.

If no unprefixed pattern defines the tag, resolution falls back silently — the element is generic, with no semantic rules applied.

### 9.4 Errors

A pattern-aware processor MUST raise an error when, and only when:

1. An element uses a prefix whose binding was not declared.
2. The same prefix is bound more than once.
3. A pattern-defined attribute is `required="true"`, absent from the element, and has no `default`.
4. A pattern-defined attribute value fails type or constraint validation **and** the schema has no `default` to fall back on.
5. A pattern declared with `strict="true"` participates in unprefixed resolution for a tag that no pattern defines.
6. A referenced pattern file fails to parse or violates the pattern schema.
7. A prefix-bound pattern is used with a tag the pattern does not define.

Cases 3 and 4 are the "cannot be computed" errors: the processor has no way to produce a semantically valid element. All other unrecognized tags fall through to silent fallback.

### 9.5 Resolution pseudocode

```
for each element E in document-order (depth-first):
    if E has prefix P:
        pattern = prefix_to_pattern[P]        # error if unbound
        tagdef = pattern.tags[E.tag]          # error if missing
        apply(tagdef, E)
    else:
        tagdef = null
        for each unprefixed pattern p in REVERSE declaration order:
            if E.tag in p.tags:
                tagdef = p.tags[E.tag]
                break
        if tagdef is null:
            if any unprefixed pattern has strict="true":
                raise
            # silent fallback: E stays generic
        else:
            apply(tagdef, E)
```

---

## 10. Pattern file format

A pattern file is a ZAckML document whose root element is `<pattern>`.

```zackml
<?zackml version="1.0" ?>
<pattern name="html-basic">

  <tag name="heading">
    <attribute name="level" type="integer" min="1" max="6" default="1"/>
    <render mode="block"/>
    <maps-to value="h{level}"/>
  </tag>

  <tag name="paragraph">
    <render mode="block"/>
    <whitespace default="collapse"/>
    <maps-to value="p"/>
  </tag>

  <tag name="emphasis">
    <render mode="inline"/>
    <maps-to value="em"/>
  </tag>

</pattern>
```

### 10.1 `<pattern>`

| Attribute | Required | Notes |
|-----------|----------|-------|
| `name`    | no       | Human-readable identifier for the pattern. |

Children: zero or more `<tag>` elements.

### 10.2 `<tag>`

| Attribute | Required | Notes |
|-----------|----------|-------|
| `name`    | yes      | The element name this definition matches. |

Permitted child elements:

- `<attribute>` — zero or more; see 10.3.
- `<render mode="block|inline|void"/>` — rendering category.
- `<whitespace default="preserve|collapse"/>` — default whitespace handling when the element has no `ws` attribute.
- `<maps-to value="..."/>` — a target name used by renderers. Value MAY reference attribute values via `{attrname}` interpolation.
- `<children allowed="name1 name2 ..."/>` — optional whitespace-separated allowlist of child tag names. Omitting permits any child.

### 10.3 `<attribute>`

| Attribute  | Required | Notes |
|------------|----------|-------|
| `name`     | yes      | |
| `type`     | no       | `"string"` (default), `"integer"`, `"number"`, `"boolean"`, `"enum"`. |
| `required` | no       | `"true"` or `"false"` (default). |
| `default`  | no       | Used when the attribute is absent, or when validation fails. |
| `min`      | no       | For `integer` / `number`. |
| `max`      | no       | For `integer` / `number`. |
| `values`   | no       | For `enum`: whitespace-separated permitted values. |

Within a tag definition, attribute names MUST be unique.

---

## 11. Metadata conventions

ZAckML does not reserve any tag names for metadata, but the following conventions are recommended and cheap for tools to agree on:

- Use **attributes** on an element for parameters bound to that element.
- Use a conventional `<meta>` section near the top of the document for document-level metadata (title, author, tags, etc.).
- Use **processing instructions** for tool-level directives that are not part of document content.

None of these are enforced by the language.

---

## 12. Errors and diagnostics

Parsers SHOULD report the line and column of every parse or resolution error. Errors SHOULD distinguish between syntactic errors (this spec, Sections 3–7) and semantic errors arising from pattern resolution (Section 9.4).

---

## Appendix A — EBNF grammar

```ebnf
Document       ::= Prolog Element Trailing
Prolog         ::= XmlDecl? (Misc)*
XmlDecl        ::= '<?zackml' S Attribute (S Attribute)* S? '?>'
Misc           ::= Comment | ProcInst | S
Trailing       ::= (Comment | S)*

ProcInst       ::= '<?' Name (S Attribute)* S? '?>'
Comment        ::= '<!--' (Char* - (Char* '-->' Char*)) '-->'

Element        ::= EmptyElem | PairedElem
EmptyElem      ::= '<' QName AttributeList? S? '/>'
PairedElem     ::= StartTag Content EndTag
StartTag       ::= '<' QName AttributeList? S? '>'
EndTag         ::= '</' QName S? '>'
QName          ::= (Name ':')? Name

AttributeList  ::= (S Attribute)+
Attribute      ::= Name S? '=' S? AttValue
AttValue       ::= '"' ((Char - ('<' | '&' | '"')) | EntityRef)* '"'
                 | "'" ((Char - ('<' | '&' | "'")) | EntityRef)* "'"

Content        ::= (Text | Element | Comment | CDATA | ProcInst)*
Text           ::= ((Char - ('<' | '&')) | EntityRef)+
CDATA          ::= '<![CDATA[' (Char* - (Char* ']]>' Char*)) ']]>'

EntityRef      ::= '&' (Name | '#' [0-9]+ | '#x' [0-9A-Fa-f]+) ';'

Name           ::= NameStart NameChar*
NameStart      ::= [A-Za-z_]
NameChar       ::= [A-Za-z0-9_-]

S              ::= (#x20 | #x9 | #xA)+
Char           ::= any Unicode scalar value
```

---

*End of ZAckML Specification v1.0*
