<?zackml version="1.0" ?>

<!--
  html-basic.pat
  A small ZAckML pattern mapping common document tags to HTML-like semantics.
-->

<pattern name="html-basic">

  <tag name="document">
    <render mode="block"/>
    <maps-to value="article"/>
  </tag>

  <tag name="heading">
    <attribute name="level" type="integer" min="1" max="6" default="1"/>
    <render mode="block"/>
    <maps-to value="h{level}"/>
  </tag>

  <tag name="paragraph">
    <render mode="block"/>
    <whitespace default="collapse"/>
    <maps-to value="p"/>
  </tag>

  <tag name="emphasis">
    <render mode="inline"/>
    <maps-to value="em"/>
  </tag>

  <tag name="strong">
    <render mode="inline"/>
    <maps-to value="strong"/>
  </tag>

  <tag name="link">
    <attribute name="href" type="string" required="true"/>
    <render mode="inline"/>
    <maps-to value="a"/>
  </tag>

  <tag name="break">
    <render mode="void"/>
    <maps-to value="br"/>
  </tag>

  <tag name="meta">
    <render mode="block"/>
  </tag>

  <tag name="title">
    <render mode="inline"/>
  </tag>

  <tag name="author">
    <render mode="inline"/>
  </tag>

</pattern>
