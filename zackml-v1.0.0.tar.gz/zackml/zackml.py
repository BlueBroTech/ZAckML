"""
ZAckML Reference Parser
=======================

A reference implementation of the ZAckML specification, version 1.0.

ZAckML is Zack's Actionable "compression key-like" Markup Language: an
XML-family markup language with no predefined tag names and an optional
in-band pattern reference system that assigns HTML-like semantics on demand.

Created by Zack VonBluebaugh (BlueBroTech, LLC).
Licensed under the MIT License — see LICENSE at the repository root.

Provides:
  - A hand-written parser producing a typed AST.
  - A loader for ZAckML pattern files (themselves ZAckML documents).
  - A resolver that applies patterns to a parsed document according to the
    prefix / last-declared / silent-fallback rules of the spec.
  - A small CLI for demoing both halves.

Usage as a library:

    from zackml import parse, parse_file, resolve, load_pattern, dump_tree

    doc = parse_file("sample.zackml")
    resolve(doc, base_path="sample.zackml")
    for line in dump_tree(doc):
        print(line)

Usage as a CLI:

    python zackml.py path/to/document.zackml
"""

from __future__ import annotations

import re
import sys
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Optional, Union


# =========================================================================
# AST node classes
# =========================================================================

@dataclass
class Comment:
    text: str
    line: int = 0
    col: int = 0


@dataclass
class Text:
    content: str
    line: int = 0
    col: int = 0


@dataclass
class CDATA:
    content: str
    line: int = 0
    col: int = 0


@dataclass
class ProcInst:
    target: str
    attrs: dict = field(default_factory=dict)
    line: int = 0
    col: int = 0


@dataclass
class Element:
    tag: str
    prefix: Optional[str] = None
    attrs: dict = field(default_factory=dict)
    children: list = field(default_factory=list)
    self_closing: bool = False
    line: int = 0
    col: int = 0
    # Filled in by the resolver; None means "generic / unresolved".
    resolved_pattern: Optional[str] = None
    resolved_tag_def: Optional["TagDef"] = None

    @property
    def qname(self) -> str:
        return f"{self.prefix}:{self.tag}" if self.prefix else self.tag


@dataclass
class Document:
    xml_decl: Optional[ProcInst] = None
    prolog: list = field(default_factory=list)      # Comments and non-xml PIs
    root: Optional[Element] = None
    trailing: list = field(default_factory=list)    # Comments after root


Node = Union[Element, Text, Comment, CDATA, ProcInst]


# =========================================================================
# Error type
# =========================================================================

class ZAckMLError(Exception):
    def __init__(self, msg: str, line: int = 0, col: int = 0):
        self.msg = msg
        self.line = line
        self.col = col
        super().__init__(f"[line {line}, col {col}] {msg}")


# Backwards-compatible alias (old name).
ZMLError = ZAckMLError


# =========================================================================
# Parser
# =========================================================================

class Parser:
    """Recursive-descent ZAckML parser with line/column tracking."""

    NAME_RE = re.compile(r"[A-Za-z_][A-Za-z0-9_-]*")
    NAMED_ENTITIES = {
        "amp": "&", "lt": "<", "gt": ">", "quot": '"', "apos": "'",
    }
    WS = " \t\n"

    def __init__(self, source: str):
        # Normalize line endings per Section 3.1 of the spec.
        source = source.replace("\r\n", "\n").replace("\r", "\n")
        self.src = source
        self.n = len(source)
        self.pos = 0
        self.line = 1
        self.col = 1

    # -------- Low-level cursor helpers --------

    def _err(self, msg: str) -> None:
        raise ZAckMLError(msg, self.line, self.col)

    def _peek(self, offset: int = 0) -> str:
        p = self.pos + offset
        return self.src[p] if p < self.n else ""

    def _advance(self, k: int = 1) -> None:
        for _ in range(k):
            if self.pos >= self.n:
                return
            c = self.src[self.pos]
            self.pos += 1
            if c == "\n":
                self.line += 1
                self.col = 1
            else:
                self.col += 1

    def _starts_with(self, s: str) -> bool:
        return self.src.startswith(s, self.pos)

    def _consume(self, s: str) -> None:
        if not self._starts_with(s):
            self._err(f"expected {s!r}")
        self._advance(len(s))

    def _skip_space(self) -> None:
        while self.pos < self.n and self.src[self.pos] in self.WS:
            self._advance()

    def _match_name(self) -> str:
        m = self.NAME_RE.match(self.src, self.pos)
        if not m:
            self._err("expected name")
        name = m.group(0)
        self._advance(len(name))
        return name

    # -------- Entity decoding --------

    def _decode_entity(self) -> str:
        """Consume an entity reference starting at '&' and return its value."""
        start_line, start_col = self.line, self.col
        self._advance()  # past '&'
        if self._peek() == "#":
            self._advance()
            if self._peek() in ("x", "X"):
                self._advance()
                start = self.pos
                while self.pos < self.n and self.src[self.pos] in "0123456789abcdefABCDEF":
                    self._advance()
                digits = self.src[start:self.pos]
                if not digits:
                    raise ZAckMLError("empty hex entity", start_line, start_col)
                code = int(digits, 16)
            else:
                start = self.pos
                while self.pos < self.n and self.src[self.pos].isdigit():
                    self._advance()
                digits = self.src[start:self.pos]
                if not digits:
                    raise ZAckMLError("empty numeric entity", start_line, start_col)
                code = int(digits)
            if self._peek() != ";":
                raise ZAckMLError("expected ';' ending numeric entity",
                               self.line, self.col)
            self._advance()
            try:
                return chr(code)
            except ValueError:
                raise ZAckMLError(f"invalid Unicode code point {code}",
                               start_line, start_col)
        else:
            m = self.NAME_RE.match(self.src, self.pos)
            if not m:
                raise ZAckMLError("expected entity name after '&'",
                               start_line, start_col)
            name = m.group(0)
            self._advance(len(name))
            if self._peek() != ";":
                raise ZAckMLError("expected ';' ending entity reference",
                               self.line, self.col)
            self._advance()
            if name not in self.NAMED_ENTITIES:
                raise ZAckMLError(f"unknown entity &{name};",
                               start_line, start_col)
            return self.NAMED_ENTITIES[name]

    # -------- Attributes --------

    def _parse_att_value(self) -> str:
        quote = self._peek()
        if quote not in ('"', "'"):
            self._err("attribute value must be quoted with \" or '")
        self._advance()
        buf: list[str] = []
        while self.pos < self.n:
            c = self.src[self.pos]
            if c == quote:
                self._advance()
                return "".join(buf)
            if c == "<":
                self._err("'<' not allowed in attribute value")
            if c == "&":
                buf.append(self._decode_entity())
            else:
                buf.append(c)
                self._advance()
        self._err("unterminated attribute value")
        return ""  # unreachable

    def _parse_attributes(self) -> dict:
        attrs: dict = {}
        while self.pos < self.n and self.src[self.pos] in self.WS:
            self._skip_space()
            c = self._peek()
            if c in ("", ">", "/", "?"):
                break
            name_line, name_col = self.line, self.col
            name = self._match_name()
            self._skip_space()
            if self._peek() != "=":
                raise ZAckMLError(f"expected '=' after attribute name {name!r}",
                               self.line, self.col)
            self._advance()
            self._skip_space()
            value = self._parse_att_value()
            if name in attrs:
                raise ZAckMLError(f"duplicate attribute {name!r}",
                               name_line, name_col)
            attrs[name] = value
        return attrs

    # -------- Top-level entry --------

    def parse_document(self) -> Document:
        doc = Document()
        # Allow a leading BOM.
        if self.pos < self.n and self.src[self.pos] == "\ufeff":
            self._advance()

        # Prolog: optional xml-decl, then comments / PIs / whitespace.
        first_pi = True
        while self.pos < self.n:
            self._skip_space()
            if self.pos >= self.n:
                self._err("document has no root element")
            if self._starts_with("<!--"):
                doc.prolog.append(self._parse_comment())
                first_pi = False
            elif self._starts_with("<?"):
                pi = self._parse_pi()
                if first_pi and pi.target == "zackml":
                    doc.xml_decl = pi
                else:
                    doc.prolog.append(pi)
                first_pi = False
            elif self._peek() == "<":
                break  # root element
            else:
                self._err("unexpected content in prolog")

        if self.pos >= self.n:
            self._err("document has no root element")

        doc.root = self._parse_element()

        # Trailing whitespace / comments allowed; no second root element.
        while self.pos < self.n:
            self._skip_space()
            if self.pos >= self.n:
                break
            if self._starts_with("<!--"):
                doc.trailing.append(self._parse_comment())
            else:
                self._err("content after root element")
        return doc

    # -------- Individual constructs --------

    def _parse_comment(self) -> Comment:
        line, col = self.line, self.col
        self._consume("<!--")
        start = self.pos
        while self.pos < self.n:
            if self._starts_with("-->"):
                text = self.src[start:self.pos]
                self._advance(3)
                return Comment(text, line, col)
            self._advance()
        raise ZAckMLError("unterminated comment", line, col)

    def _parse_pi(self) -> ProcInst:
        line, col = self.line, self.col
        self._consume("<?")
        target = self._match_name()
        attrs: dict = {}
        if self.pos < self.n and self.src[self.pos] in self.WS:
            attrs = self._parse_attributes()
        self._skip_space()
        if not self._starts_with("?>"):
            self._err("expected '?>' to end processing instruction")
        self._advance(2)
        return ProcInst(target, attrs, line, col)

    def _parse_cdata(self) -> CDATA:
        line, col = self.line, self.col
        self._consume("<![CDATA[")
        start = self.pos
        while self.pos < self.n:
            if self._starts_with("]]>"):
                text = self.src[start:self.pos]
                self._advance(3)
                return CDATA(text, line, col)
            self._advance()
        raise ZAckMLError("unterminated CDATA section", line, col)

    def _parse_qname(self) -> tuple[Optional[str], str]:
        first = self._match_name()
        if self._peek() == ":":
            self._advance()
            second = self._match_name()
            return first, second
        return None, first

    def _parse_element(self) -> Element:
        line, col = self.line, self.col
        self._consume("<")
        prefix, tag = self._parse_qname()
        attrs: dict = {}
        if self.pos < self.n and self.src[self.pos] in self.WS:
            attrs = self._parse_attributes()
        self._skip_space()
        if self._starts_with("/>"):
            self._advance(2)
            return Element(tag=tag, prefix=prefix, attrs=attrs,
                           children=[], self_closing=True,
                           line=line, col=col)
        if self._peek() != ">":
            self._err("expected '>' or '/>' at end of start tag")
        self._advance()
        children = self._parse_content()
        # End tag.
        end_line, end_col = self.line, self.col
        self._consume("</")
        end_prefix, end_tag = self._parse_qname()
        if end_tag != tag or end_prefix != prefix:
            start_q = f"{prefix + ':' if prefix else ''}{tag}"
            end_q = f"{end_prefix + ':' if end_prefix else ''}{end_tag}"
            raise ZAckMLError(
                f"end tag </{end_q}> does not match start tag <{start_q}>",
                end_line, end_col,
            )
        self._skip_space()
        if self._peek() != ">":
            self._err("expected '>' at end of end tag")
        self._advance()
        return Element(tag=tag, prefix=prefix, attrs=attrs,
                       children=children, self_closing=False,
                       line=line, col=col)

    def _parse_content(self) -> list:
        children: list = []
        buf: list[str] = []
        text_start = (self.line, self.col)

        def flush():
            if buf:
                children.append(Text("".join(buf), text_start[0], text_start[1]))
                buf.clear()

        while self.pos < self.n:
            if self._starts_with("</"):
                flush()
                return children
            if self._starts_with("<!--"):
                flush()
                children.append(self._parse_comment())
                text_start = (self.line, self.col)
            elif self._starts_with("<![CDATA["):
                flush()
                children.append(self._parse_cdata())
                text_start = (self.line, self.col)
            elif self._starts_with("<?"):
                flush()
                children.append(self._parse_pi())
                text_start = (self.line, self.col)
            elif self._peek() == "<":
                flush()
                children.append(self._parse_element())
                text_start = (self.line, self.col)
            elif self._peek() == "&":
                if not buf:
                    text_start = (self.line, self.col)
                buf.append(self._decode_entity())
            else:
                if not buf:
                    text_start = (self.line, self.col)
                buf.append(self.src[self.pos])
                self._advance()
        self._err("unexpected end of input (expected closing tag)")
        return []  # unreachable


def parse(source: str) -> Document:
    """Parse a ZAckML string into a Document."""
    return Parser(source).parse_document()


def parse_file(path: Union[str, Path]) -> Document:
    """Parse a ZAckML file into a Document."""
    with open(path, "r", encoding="utf-8") as f:
        return parse(f.read())


# =========================================================================
# Pattern representation
# =========================================================================

@dataclass
class AttrSchema:
    name: str
    type: str = "string"
    required: bool = False
    default: Optional[str] = None
    min: Optional[float] = None
    max: Optional[float] = None
    values: Optional[list] = None  # for enum


@dataclass
class TagDef:
    name: str
    render: Optional[str] = None          # block | inline | void
    whitespace: Optional[str] = None      # preserve | collapse
    maps_to: Optional[str] = None
    allowed_children: Optional[list] = None
    attrs: dict = field(default_factory=dict)  # name -> AttrSchema


@dataclass
class Pattern:
    name: str
    tags: dict = field(default_factory=dict)   # name -> TagDef
    source_path: Optional[str] = None


def load_pattern(path: Union[str, Path]) -> Pattern:
    """Load and validate a .pat file (itself a ZAckML document)."""
    path = Path(path)
    doc = parse_file(path)
    root = doc.root
    if root is None or root.tag != "pattern" or root.prefix:
        line = root.line if root else 0
        col = root.col if root else 0
        raise ZAckMLError(
            f"pattern file must have root <pattern>, got <{root.qname if root else '?'}>",
            line, col,
        )

    pat = Pattern(name=root.attrs.get("name", "anonymous"),
                  source_path=str(path))

    for child in root.children:
        if not isinstance(child, Element):
            continue  # ignore whitespace text, comments, etc.
        if child.tag != "tag" or child.prefix:
            raise ZAckMLError(f"unexpected child <{child.qname}> in pattern",
                           child.line, child.col)
        if "name" not in child.attrs:
            raise ZAckMLError("<tag> missing 'name' attribute",
                           child.line, child.col)
        tag_def = TagDef(name=child.attrs["name"])
        for grand in child.children:
            if not isinstance(grand, Element):
                continue
            if grand.tag == "render":
                tag_def.render = grand.attrs.get("mode")
            elif grand.tag == "whitespace":
                tag_def.whitespace = grand.attrs.get("default")
            elif grand.tag == "maps-to":
                tag_def.maps_to = grand.attrs.get("value")
            elif grand.tag == "children":
                allowed = grand.attrs.get("allowed", "")
                tag_def.allowed_children = allowed.split() if allowed else []
            elif grand.tag == "attribute":
                a = grand.attrs
                if "name" not in a:
                    raise ZAckMLError("<attribute> missing 'name'",
                                   grand.line, grand.col)
                schema = AttrSchema(
                    name=a["name"],
                    type=a.get("type", "string"),
                    required=(a.get("required", "false").lower() == "true"),
                    default=a.get("default"),
                    min=float(a["min"]) if "min" in a else None,
                    max=float(a["max"]) if "max" in a else None,
                    values=a["values"].split() if "values" in a else None,
                )
                tag_def.attrs[schema.name] = schema
            else:
                raise ZAckMLError(
                    f"unexpected element <{grand.qname}> in tag definition",
                    grand.line, grand.col,
                )
        pat.tags[tag_def.name] = tag_def
    return pat


# =========================================================================
# Resolver
# =========================================================================

def resolve(doc: Document, base_path: Union[str, Path, None] = None) -> Document:
    """Resolve `<?pattern?>` declarations and attach semantics to elements.

    `base_path` is used to resolve relative pattern `src` attributes; pass the
    path of the document itself (or None if patterns use absolute paths).
    """
    base = Path(base_path).parent if base_path else Path(".")

    # List of (Pattern, prefix_or_None, strict_bool) in declaration order.
    patterns_in_order: list[tuple[Pattern, Optional[str], bool]] = []
    prefix_to_pattern: dict[str, Pattern] = {}

    for item in doc.prolog:
        if not (isinstance(item, ProcInst) and item.target == "pattern"):
            continue
        src = item.attrs.get("src")
        if not src:
            raise ZAckMLError("<?pattern?> missing 'src' attribute",
                           item.line, item.col)
        prefix = item.attrs.get("as")
        strict = item.attrs.get("strict", "false").lower() == "true"
        pat_path = base / src
        pat = load_pattern(pat_path)
        if prefix is not None:
            if prefix in prefix_to_pattern:
                raise ZAckMLError(f"duplicate pattern prefix {prefix!r}",
                               item.line, item.col)
            prefix_to_pattern[prefix] = pat
        patterns_in_order.append((pat, prefix, strict))

    if doc.root is not None:
        _resolve_element(doc.root, patterns_in_order, prefix_to_pattern)
    return doc


def _resolve_element(el: Element,
                     patterns_in_order: list[tuple[Pattern, Optional[str], bool]],
                     prefix_to_pattern: dict[str, Pattern]) -> None:
    if el.prefix is not None:
        pat = prefix_to_pattern.get(el.prefix)
        if pat is None:
            raise ZAckMLError(f"undeclared prefix {el.prefix!r}", el.line, el.col)
        tag_def = pat.tags.get(el.tag)
        if tag_def is None:
            raise ZAckMLError(
                f"tag <{el.prefix}:{el.tag}> not defined in pattern {pat.name!r}",
                el.line, el.col,
            )
        el.resolved_pattern = pat.name
        el.resolved_tag_def = tag_def
        _apply_tag_def(el, tag_def)
    else:
        found: Optional[tuple[Pattern, TagDef]] = None
        # Last-declared-unprefixed-pattern-that-defines-the-tag wins.
        for pat, prefix, _strict in reversed(patterns_in_order):
            if prefix is not None:
                continue  # prefix-bound patterns don't play here
            if el.tag in pat.tags:
                found = (pat, pat.tags[el.tag])
                break
        if found is None:
            # Strict-mode check across all unprefixed patterns.
            for pat, prefix, strict in patterns_in_order:
                if prefix is None and strict:
                    raise ZAckMLError(
                        f"strict pattern {pat.name!r} has no definition "
                        f"for <{el.tag}>",
                        el.line, el.col,
                    )
            # Silent fallback: element remains generic.
        else:
            pat, tag_def = found
            el.resolved_pattern = pat.name
            el.resolved_tag_def = tag_def
            _apply_tag_def(el, tag_def)

    for child in el.children:
        if isinstance(child, Element):
            _resolve_element(child, patterns_in_order, prefix_to_pattern)


def _apply_tag_def(el: Element, tag_def: TagDef) -> None:
    """Validate attributes, fill in defaults, apply whitespace default."""
    # Whitespace default from pattern (only if element lacks explicit ws).
    if tag_def.whitespace and "ws" not in el.attrs:
        el.attrs["ws"] = tag_def.whitespace

    for schema in tag_def.attrs.values():
        if schema.name not in el.attrs:
            if schema.default is not None:
                el.attrs[schema.name] = schema.default
                continue
            if schema.required:
                raise ZAckMLError(
                    f"required attribute {schema.name!r} missing on "
                    f"<{el.qname}> and no default available",
                    el.line, el.col,
                )
            continue
        raw = el.attrs[schema.name]
        try:
            _validate(raw, schema)
        except ValueError as e:
            if schema.default is not None:
                el.attrs[schema.name] = schema.default
            else:
                raise ZAckMLError(
                    f"attribute {schema.name!r}={raw!r} invalid: {e} "
                    f"(no default available)",
                    el.line, el.col,
                )


def _validate(raw: str, schema: AttrSchema) -> None:
    t = schema.type
    if t == "string":
        return
    if t == "integer":
        try:
            v = int(raw)
        except ValueError:
            raise ValueError(f"expected integer, got {raw!r}")
        if schema.min is not None and v < schema.min:
            raise ValueError(f"value {v} below minimum {schema.min}")
        if schema.max is not None and v > schema.max:
            raise ValueError(f"value {v} above maximum {schema.max}")
        return
    if t == "number":
        try:
            v = float(raw)
        except ValueError:
            raise ValueError(f"expected number, got {raw!r}")
        if schema.min is not None and v < schema.min:
            raise ValueError(f"value {v} below minimum {schema.min}")
        if schema.max is not None and v > schema.max:
            raise ValueError(f"value {v} above maximum {schema.max}")
        return
    if t == "boolean":
        if raw.lower() not in ("true", "false"):
            raise ValueError(f"expected 'true' or 'false', got {raw!r}")
        return
    if t == "enum":
        if schema.values and raw not in schema.values:
            raise ValueError(f"value {raw!r} not in enum {schema.values}")
        return
    raise ValueError(f"unknown type {t!r}")


# =========================================================================
# Pretty printer (for CLI demo)
# =========================================================================

def dump_tree(node: Any, indent: int = 0) -> list[str]:
    pad = "  " * indent
    if isinstance(node, Document):
        lines: list[str] = []
        if node.xml_decl:
            lines.append(f"{pad}XmlDecl {node.xml_decl.attrs}")
        for p in node.prolog:
            lines.extend(dump_tree(p, indent))
        if node.root is not None:
            lines.extend(dump_tree(node.root, indent))
        for t in node.trailing:
            lines.extend(dump_tree(t, indent))
        return lines
    if isinstance(node, Element):
        mapping = ""
        if node.resolved_tag_def and node.resolved_tag_def.maps_to:
            try:
                mapping = " -> " + node.resolved_tag_def.maps_to.format(**node.attrs)
            except (KeyError, IndexError):
                mapping = " -> " + node.resolved_tag_def.maps_to
        pat = f" [{node.resolved_pattern}]" if node.resolved_pattern else " [generic]"
        out = [f"{pad}<{node.qname} {node.attrs}>{pat}{mapping}"]
        for c in node.children:
            out.extend(dump_tree(c, indent + 1))
        out.append(f"{pad}</{node.qname}>")
        return out
    if isinstance(node, Text):
        return [f"{pad}TEXT {node.content!r}"]
    if isinstance(node, Comment):
        return [f"{pad}<!--{node.text}-->"]
    if isinstance(node, CDATA):
        return [f"{pad}CDATA {node.content!r}"]
    if isinstance(node, ProcInst):
        return [f"{pad}<?{node.target} {node.attrs}?>"]
    return [f"{pad}{node!r}"]


# =========================================================================
# CLI
# =========================================================================

def main(argv: list[str]) -> int:
    if len(argv) < 2:
        print("usage: python zackml.py FILE.zackml")
        return 1
    path = argv[1]
    try:
        doc = parse_file(path)
        resolve(doc, base_path=path)
    except ZAckMLError as e:
        print(f"ZAckML error in {path}: {e}", file=sys.stderr)
        return 2
    for line in dump_tree(doc):
        print(line)
    return 0


if __name__ == "__main__":
    sys.exit(main(sys.argv))
