"""
render.py — render a ZAckML document (resolved with the svg pattern) to real SVG.

Usage:
    python render.py logo.zackml > logo.svg

The renderer is intentionally tiny: for every element, it emits a real tag whose
name comes from the pattern's `maps-to` value. It proves the "actionable" part
of ZAckML — patterns carry enough information that a consumer can do real work
with the tree without hard-coding tag names.

Assumes zackml.py is importable (see PYTHONPATH / sys.path tweak below).
"""

from __future__ import annotations

import sys
from pathlib import Path

# Make zackml.py importable whether render.py runs from the repo layout
# (uses/svg/render.py with zackml.py at the repo root) or the standalone
# layout used during development (zackml-uses/svg/render.py with zackml.py
# living in a sibling zackml/ directory).
HERE = Path(__file__).resolve().parent
for _candidate in (HERE.parent.parent, HERE.parent.parent / "zackml"):
    if (_candidate / "zackml.py").exists():
        sys.path.insert(0, str(_candidate))
        break

from zackml import parse_file, resolve, Element, Text, CDATA  # noqa: E402


# SVG attributes that use hyphens in the real spec but are conventionally
# lowercase in ZAckML patterns.
ATTR_RENAME = {
    "viewbox": "viewBox",  # SVG is case-sensitive on this one.
}


def escape_text(s: str) -> str:
    return (s.replace("&", "&amp;")
             .replace("<", "&lt;")
             .replace(">", "&gt;"))


def escape_attr(s: str) -> str:
    return escape_text(s).replace('"', "&quot;")


def render(el: Element) -> str:
    if el.resolved_tag_def is None or not el.resolved_tag_def.maps_to:
        # Silent fallback: skip unknown tags but keep their children.
        return "".join(render(c) for c in el.children if isinstance(c, Element))

    tag = el.resolved_tag_def.maps_to.format(**el.attrs)

    # Drop ZAckML-internal attributes; rename hyphenated SVG ones.
    rendered_attrs = []
    for name, value in el.attrs.items():
        if name == "ws":
            continue
        out_name = ATTR_RENAME.get(name, name)
        rendered_attrs.append(f'{out_name}="{escape_attr(value)}"')
    attr_str = (" " + " ".join(rendered_attrs)) if rendered_attrs else ""

    if el.resolved_tag_def.render == "void":
        return f"<{tag}{attr_str}/>"

    parts = [f"<{tag}{attr_str}>"]
    for child in el.children:
        if isinstance(child, Element):
            parts.append(render(child))
        elif isinstance(child, Text):
            parts.append(escape_text(child.content))
        elif isinstance(child, CDATA):
            parts.append(escape_text(child.content))
    parts.append(f"</{tag}>")
    return "".join(parts)


def main(argv: list[str]) -> int:
    if len(argv) < 2:
        print("usage: python render.py FILE.zackml", file=sys.stderr)
        return 1
    path = argv[1]
    doc = parse_file(path)
    resolve(doc, base_path=path)
    if doc.root is None:
        print("empty document", file=sys.stderr)
        return 2
    print('<?xml version="1.0" encoding="utf-8"?>')
    print(render(doc.root))
    return 0


if __name__ == "__main__":
    sys.exit(main(sys.argv))
