<?zackml version="1.0" ?>

<!--
  svg.pat
  A ZAckML pattern whose tags map one-to-one to SVG shape elements.
  Because every tag declares `maps-to`, a renderer can walk the resolved
  tree and emit real SVG mechanically.
-->

<pattern name="svg">

  <tag name="svg">
    <attribute name="width"   type="number"/>
    <attribute name="height"  type="number"/>
    <attribute name="viewbox" type="string"/>
    <render mode="block"/>
    <maps-to value="svg"/>
  </tag>

  <tag name="group">
    <attribute name="id"        type="string"/>
    <attribute name="transform" type="string"/>
    <attribute name="fill"      type="string"/>
    <attribute name="stroke"    type="string"/>
    <attribute name="opacity"   type="number" min="0" max="1" default="1"/>
    <render mode="block"/>
    <maps-to value="g"/>
  </tag>

  <tag name="rect">
    <attribute name="x"            type="number" default="0"/>
    <attribute name="y"            type="number" default="0"/>
    <attribute name="width"        type="number" required="true"/>
    <attribute name="height"       type="number" required="true"/>
    <attribute name="rx"           type="number" default="0"/>
    <attribute name="ry"           type="number" default="0"/>
    <attribute name="fill"         type="string" default="black"/>
    <attribute name="stroke"       type="string" default="none"/>
    <attribute name="stroke-width" type="number" default="1"/>
    <render mode="void"/>
    <maps-to value="rect"/>
  </tag>

  <tag name="circle">
    <attribute name="cx"           type="number" default="0"/>
    <attribute name="cy"           type="number" default="0"/>
    <attribute name="r"            type="number" required="true"/>
    <attribute name="fill"         type="string" default="black"/>
    <attribute name="stroke"       type="string" default="none"/>
    <attribute name="stroke-width" type="number" default="1"/>
    <render mode="void"/>
    <maps-to value="circle"/>
  </tag>

  <tag name="ellipse">
    <attribute name="cx"   type="number" default="0"/>
    <attribute name="cy"   type="number" default="0"/>
    <attribute name="rx"   type="number" required="true"/>
    <attribute name="ry"   type="number" required="true"/>
    <attribute name="fill" type="string" default="black"/>
    <render mode="void"/>
    <maps-to value="ellipse"/>
  </tag>

  <tag name="line">
    <attribute name="x1"           type="number" required="true"/>
    <attribute name="y1"           type="number" required="true"/>
    <attribute name="x2"           type="number" required="true"/>
    <attribute name="y2"           type="number" required="true"/>
    <attribute name="stroke"       type="string" default="black"/>
    <attribute name="stroke-width" type="number" default="1"/>
    <render mode="void"/>
    <maps-to value="line"/>
  </tag>

  <tag name="path">
    <attribute name="d"            type="string" required="true"/>
    <attribute name="fill"         type="string" default="black"/>
    <attribute name="stroke"       type="string" default="none"/>
    <attribute name="stroke-width" type="number" default="1"/>
    <render mode="void"/>
    <maps-to value="path"/>
  </tag>

  <tag name="polygon">
    <attribute name="points"       type="string" required="true"/>
    <attribute name="fill"         type="string" default="black"/>
    <attribute name="stroke"       type="string" default="none"/>
    <attribute name="stroke-width" type="number" default="1"/>
    <render mode="void"/>
    <maps-to value="polygon"/>
  </tag>

  <tag name="text">
    <attribute name="x"           type="number" default="0"/>
    <attribute name="y"           type="number" default="0"/>
    <attribute name="font-family" type="string" default="sans-serif"/>
    <attribute name="font-size"   type="number" default="12"/>
    <attribute name="font-weight" type="string" default="normal"/>
    <attribute name="fill"        type="string" default="black"/>
    <attribute name="text-anchor" type="enum" values="start middle end" default="start"/>
    <render mode="inline"/>
    <whitespace default="preserve"/>
    <maps-to value="text"/>
  </tag>

</pattern>
