# ZAckML in the wild

Four worked examples showing how ZAckML can serve as the underlying markup for real-world file formats. Each example consists of a **pattern file** (defining the semantics of a handful of tags) and one or more **document files** (using those tags).

Every file here parses and resolves cleanly against the reference parser from the core ZAckML delivery.

---

## 1. Office documents — `office/`

Microsoft Word `.docx` files are ZIP archives containing XML. The main content lives in `word/document.xml`, styling in `word/styles.xml`, and so on. Swap that XML for ZAckML and the container story stays identical — ZIP of ZAckML files — while authors gain the in-band pattern system for free.

- **`office-doc.pat`** — word-processing semantics: `<document>`, `<section>`, `<heading>`, `<paragraph>`, `<run>` (for inline character formatting), `<list>`/`<item>`, `<table>`/`<row>`/`<cell>`, `<image>`, `<page-break>`.
- **`letter.zackml`** — a short business letter with a heading, an ordered list, and a comparison table.

## 2. Spreadsheets — `office/`

`.xlsx` files follow the same container idea with SpreadsheetML inside. The ZAckML analogue:

- **`spreadsheet.pat`** — `<workbook>`, `<sheet>`, `<columns>`/`<column>`, `<row>`, `<cell>` with `type` (`string`, `number`, `currency`, `percent`, `date`, `boolean`, `formula`), optional `formula`, and format strings. Plus `<named-range>`.
- **`budget.zackml`** — a two-sheet workbook. The `Summary` sheet has typed cells, percent formatting, formulas, and a SUM total. The `Log` sheet holds raw transactions.

## 3. EPUB eBooks — `epub/`

An EPUB is a ZIP of two things: per-chapter content documents (XHTML today) and a package file (the OPF) carrying metadata, a manifest, and a spine for reading order. Two small patterns capture both halves:

- **`epub-content.pat`** — chapter content: `<chapter>`, `<title>`/`<subtitle>`, `<section>`, `<paragraph>`, `<emphasis>`/`<strong>`, `<blockquote>`, `<footnote-ref>`/`<footnote>`.
- **`epub-package.pat`** — package metadata: `<package>`, `<metadata>` (title, author with role, language, identifier, publisher, date, description), `<manifest>`/`<item>`, `<spine>`/`<itemref>`.
- **`chapter-1.zackml`** — a sample opening chapter with a footnote and a blockquote.
- **`package.zackml`** — the corresponding package document that declares the book's metadata and ties its files together.

Media-type for the content files would conventionally be `application/zackml+xml`, as shown in the manifest.

## 4. SVG graphics — `svg/`

SVG's tags are a closed set (`<rect>`, `<circle>`, `<path>`, `<g>`, …) but from ZAckML's perspective nothing is special about them — they're just names a pattern binds to rendering instructions. Because every tag in the pattern declares `maps-to` against the corresponding real SVG name, rendering is mechanical.

- **`svg.pat`** — shape and container tags with geometry and style attributes: `<svg>`, `<group>`, `<rect>`, `<circle>`, `<ellipse>`, `<line>`, `<path>`, `<polygon>`, `<text>`. Default fills, strokes, and stroke widths are declared in the pattern so documents stay clean.
- **`logo.zackml`** — a small ZAckML wordmark drawn with the pattern.
- **`logo.svg`** — the result of running the renderer. Opens in any browser. Illustrates that attribute defaults from the pattern (stroke, stroke-width, fill, rx, ry…) actually land in the output.
- **`render.py`** — a 60-line renderer that parses a document, resolves it against the pattern, and walks the resolved tree emitting real SVG. This is the concrete payoff of the `maps-to` field in patterns: tags carry enough metadata for a consumer to do real work.

### Running the renderer

```
$ python render.py logo.zackml > logo.svg
```

---

## How these scale to real containers

The Office and EPUB examples above cover just the *markup* side of each format. A true `.docx`/`.xlsx`/`.epub` bundle is a ZIP containing many such markup files plus images, fonts, and stylesheets. The pattern-per-role approach extends cleanly: one pattern per distinct role in the container (content, styling, manifest, metadata), each referenced from the file that uses it.

The point is that no tag in any of these examples is built into the language. `<paragraph>`, `<cell>`, `<spine>`, `<rect>` — all of them are plain ZAckML element names until a pattern hands them meaning. The language stays generic; the ecosystem accrues in `.pat` files.
