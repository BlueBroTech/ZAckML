<?zackml version="1.0" ?>

<!--
  office-doc.pat
  Word-processing pattern. The shape mirrors the essentials of WordprocessingML
  (the XML inside .docx files): a document of sections, each a sequence of
  block-level paragraphs or tables, with formatted inline runs inside.
-->

<pattern name="office-doc">

  <tag name="document">
    <render mode="block"/>
  </tag>

  <tag name="section">
    <attribute name="orientation" type="enum" values="portrait landscape" default="portrait"/>
    <attribute name="margin-top"    type="number" default="1.0"/>
    <attribute name="margin-bottom" type="number" default="1.0"/>
    <attribute name="margin-left"   type="number" default="1.0"/>
    <attribute name="margin-right"  type="number" default="1.0"/>
    <render mode="block"/>
  </tag>

  <tag name="heading">
    <attribute name="level" type="integer" min="1" max="6" default="1"/>
    <attribute name="style" type="string" default="Heading"/>
    <render mode="block"/>
    <whitespace default="collapse"/>
    <maps-to value="h{level}"/>
  </tag>

  <tag name="paragraph">
    <attribute name="style" type="string" default="Normal"/>
    <attribute name="align" type="enum" values="left center right justify" default="left"/>
    <render mode="block"/>
    <whitespace default="collapse"/>
    <maps-to value="p"/>
  </tag>

  <tag name="run">
    <attribute name="bold"      type="boolean" default="false"/>
    <attribute name="italic"    type="boolean" default="false"/>
    <attribute name="underline" type="boolean" default="false"/>
    <attribute name="font"      type="string"  default="Calibri"/>
    <attribute name="size"      type="number"  default="11"/>
    <render mode="inline"/>
    <maps-to value="span"/>
  </tag>

  <tag name="link">
    <attribute name="href" type="string" required="true"/>
    <render mode="inline"/>
    <maps-to value="a"/>
  </tag>

  <tag name="list">
    <attribute name="type" type="enum" values="ordered unordered" default="unordered"/>
    <render mode="block"/>
  </tag>

  <tag name="item">
    <render mode="block"/>
    <maps-to value="li"/>
  </tag>

  <tag name="table">
    <attribute name="border" type="integer" default="1"/>
    <render mode="block"/>
    <maps-to value="table"/>
  </tag>

  <tag name="row">
    <render mode="block"/>
    <maps-to value="tr"/>
  </tag>

  <tag name="cell">
    <attribute name="span" type="integer" min="1" default="1"/>
    <render mode="block"/>
    <maps-to value="td"/>
  </tag>

  <tag name="image">
    <attribute name="src"    type="string" required="true"/>
    <attribute name="width"  type="number"/>
    <attribute name="height" type="number"/>
    <attribute name="alt"    type="string" default=""/>
    <render mode="void"/>
    <maps-to value="img"/>
  </tag>

  <tag name="page-break">
    <render mode="void"/>
  </tag>

</pattern>
