<?zackml version="1.0" ?>

<!--
  spreadsheet.pat
  A pattern for tabular data, in the spirit of SpreadsheetML inside .xlsx.
  Cells carry a type, an optional formula, and a raw value.
-->

<pattern name="spreadsheet">

  <tag name="workbook">
    <attribute name="author" type="string" default=""/>
    <render mode="block"/>
  </tag>

  <tag name="sheet">
    <attribute name="name"  type="string" required="true"/>
    <attribute name="index" type="integer" min="0" default="0"/>
    <render mode="block"/>
  </tag>

  <tag name="columns">
    <render mode="block"/>
  </tag>

  <tag name="column">
    <attribute name="index" type="integer" min="1" required="true"/>
    <attribute name="width" type="number"  default="10"/>
    <attribute name="name"  type="string"  default=""/>
    <render mode="void"/>
  </tag>

  <tag name="row">
    <attribute name="index"  type="integer" min="1" required="true"/>
    <attribute name="height" type="number"  default="15"/>
    <render mode="block"/>
    <maps-to value="tr"/>
  </tag>

  <tag name="cell">
    <attribute name="column"  type="integer" min="1" required="true"/>
    <attribute name="type"    type="enum" values="string number currency percent date boolean formula" default="string"/>
    <attribute name="formula" type="string"/>
    <attribute name="format"  type="string" default=""/>
    <render mode="inline"/>
    <whitespace default="collapse"/>
    <maps-to value="td"/>
  </tag>

  <tag name="named-range">
    <attribute name="name"  type="string" required="true"/>
    <attribute name="range" type="string" required="true"/>
    <render mode="void"/>
  </tag>

</pattern>
