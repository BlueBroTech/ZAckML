<?zackml version="1.0" ?>

<!--
  epub-package.pat
  Package-side pattern — analogue of EPUB's OPF file. Carries book-level
  metadata, a manifest of files, and a spine giving the reading order.
-->

<pattern name="epub-package">

  <tag name="package">
    <attribute name="version" type="string" default="3.0"/>
    <render mode="block"/>
  </tag>

  <tag name="metadata">
    <render mode="block"/>
  </tag>

  <tag name="title">
    <render mode="inline"/>
  </tag>

  <tag name="author">
    <attribute name="role" type="string" default="author"/>
    <render mode="inline"/>
  </tag>

  <tag name="language">
    <render mode="inline"/>
  </tag>

  <tag name="identifier">
    <attribute name="scheme" type="string" default="isbn"/>
    <render mode="inline"/>
  </tag>

  <tag name="publisher">
    <render mode="inline"/>
  </tag>

  <tag name="date">
    <render mode="inline"/>
  </tag>

  <tag name="description">
    <render mode="inline"/>
    <whitespace default="collapse"/>
  </tag>

  <tag name="manifest">
    <render mode="block"/>
  </tag>

  <tag name="item">
    <attribute name="id"         type="string" required="true"/>
    <attribute name="href"       type="string" required="true"/>
    <attribute name="media-type" type="string" required="true"/>
    <render mode="void"/>
  </tag>

  <tag name="spine">
    <render mode="block"/>
  </tag>

  <tag name="itemref">
    <attribute name="idref"  type="string"  required="true"/>
    <attribute name="linear" type="boolean" default="true"/>
    <render mode="void"/>
  </tag>

</pattern>
