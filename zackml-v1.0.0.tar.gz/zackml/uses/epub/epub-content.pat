<?zackml version="1.0" ?>

<!--
  epub-content.pat
  Content-side pattern for long-form prose, inspired by EPUB's XHTML
  chapter documents. Focused on what a novel or essay actually needs:
  headings, paragraphs, emphasis, blockquotes, footnotes.
-->

<pattern name="epub-content">

  <tag name="chapter">
    <attribute name="id"     type="string"  required="true"/>
    <attribute name="number" type="integer" min="0"/>
    <render mode="block"/>
    <maps-to value="section"/>
  </tag>

  <tag name="title">
    <render mode="block"/>
    <whitespace default="collapse"/>
    <maps-to value="h1"/>
  </tag>

  <tag name="subtitle">
    <render mode="block"/>
    <whitespace default="collapse"/>
    <maps-to value="h2"/>
  </tag>

  <tag name="section">
    <render mode="block"/>
    <maps-to value="section"/>
  </tag>

  <tag name="paragraph">
    <render mode="block"/>
    <whitespace default="collapse"/>
    <maps-to value="p"/>
  </tag>

  <tag name="emphasis">
    <render mode="inline"/>
    <maps-to value="em"/>
  </tag>

  <tag name="strong">
    <render mode="inline"/>
    <maps-to value="strong"/>
  </tag>

  <tag name="blockquote">
    <attribute name="cite" type="string"/>
    <render mode="block"/>
    <whitespace default="collapse"/>
    <maps-to value="blockquote"/>
  </tag>

  <tag name="footnote-ref">
    <attribute name="id" type="string" required="true"/>
    <render mode="inline"/>
    <maps-to value="sup"/>
  </tag>

  <tag name="footnote">
    <attribute name="id" type="string" required="true"/>
    <render mode="block"/>
    <whitespace default="collapse"/>
    <maps-to value="aside"/>
  </tag>

  <tag name="break">
    <render mode="void"/>
    <maps-to value="br"/>
  </tag>

</pattern>
